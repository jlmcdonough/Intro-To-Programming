# CMPT120-Project-McDonough
Joseph McDonough Introduction to Programming Project
Name of the game is "Last Stand" and takes place in London in the middle of an epidemic.
The player chooses a role out of a role list that will determine the strengths and weaknesses of the character.
The ultimate goal is to gather the necessary supplies, avoid the gangs, and outlive the epidemic and hopefully return home.
Good luck!
